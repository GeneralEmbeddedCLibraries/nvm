var searchData=
[
  ['p_5fdriver_40',['p_driver',['../structnvm__region__s.html#ad7ff41080becfd0c0cc925499222bbee',1,'nvm_region_s']]],
  ['pf_5fnvm_5ferase_41',['pf_nvm_erase',['../structnvm__mem__driver__s.html#a8241f1c0b5f60bc6170ad4cdd917dde2',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5finit_42',['pf_nvm_init',['../structnvm__mem__driver__s.html#a27448056011e41e3d4e806150ff4d040',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5fread_43',['pf_nvm_read',['../structnvm__mem__driver__s.html#a5beab15bdb96b939c2b810882d533171',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5fwrite_44',['pf_nvm_write',['../structnvm__mem__driver__s.html#a193e95d9530c5f05e44c024c847fcc39',1,'nvm_mem_driver_s']]]
];
