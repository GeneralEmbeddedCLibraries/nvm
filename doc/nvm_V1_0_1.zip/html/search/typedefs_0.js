var searchData=
[
  ['nvm_5fmem_5fdriver_5ft_47',['nvm_mem_driver_t',['../group___n_v_m.html#ga1985b8baf6174aa9863e48c74adaba2d',1,'nvm.h']]],
  ['nvm_5fregion_5ft_48',['nvm_region_t',['../group___n_v_m.html#gaabbbe4f5dc7b4a331f8b93ad4ace468b',1,'nvm.h']]]
];
