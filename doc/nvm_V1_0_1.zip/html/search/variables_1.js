var searchData=
[
  ['name_39',['name',['../structnvm__region__s.html#a1cd49c10b06e2dcdc6240a6b96bce792',1,'nvm_region_s']]]
];
