var searchData=
[
  ['size_45',['size',['../structnvm__region__s.html#abb0d544f7f13eab892d315959435c453',1,'nvm_region_s']]],
  ['start_5faddr_46',['start_addr',['../structnvm__region__s.html#a89f0759d4cddab7feae7136541cb42af',1,'nvm_region_s']]]
];
