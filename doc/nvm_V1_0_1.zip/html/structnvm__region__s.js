var structnvm__region__s =
[
    [ "name", "structnvm__region__s.html#a1cd49c10b06e2dcdc6240a6b96bce792", null ],
    [ "p_driver", "structnvm__region__s.html#ad7ff41080becfd0c0cc925499222bbee", null ],
    [ "size", "structnvm__region__s.html#abb0d544f7f13eab892d315959435c453", null ],
    [ "start_addr", "structnvm__region__s.html#a89f0759d4cddab7feae7136541cb42af", null ]
];