var structnvm__mem__driver__s =
[
    [ "pf_nvm_erase", "group___n_v_m.html#ga8241f1c0b5f60bc6170ad4cdd917dde2", null ],
    [ "pf_nvm_init", "group___n_v_m.html#ga27448056011e41e3d4e806150ff4d040", null ],
    [ "pf_nvm_read", "group___n_v_m.html#ga5beab15bdb96b939c2b810882d533171", null ],
    [ "pf_nvm_write", "group___n_v_m.html#ga193e95d9530c5f05e44c024c847fcc39", null ]
];