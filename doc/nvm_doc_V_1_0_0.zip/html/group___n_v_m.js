var group___n_v_m =
[
    [ "nvm_mem_driver_s", "structnvm__mem__driver__s.html", [
      [ "pf_nvm_erase", "group___n_v_m.html#ga8241f1c0b5f60bc6170ad4cdd917dde2", null ],
      [ "pf_nvm_init", "group___n_v_m.html#ga27448056011e41e3d4e806150ff4d040", null ],
      [ "pf_nvm_read", "group___n_v_m.html#ga5beab15bdb96b939c2b810882d533171", null ],
      [ "pf_nvm_write", "group___n_v_m.html#ga193e95d9530c5f05e44c024c847fcc39", null ]
    ] ],
    [ "nvm_region_s", "structnvm__region__s.html", [
      [ "name", "group___n_v_m.html#ga1cd49c10b06e2dcdc6240a6b96bce792", null ],
      [ "p_driver", "group___n_v_m.html#gad7ff41080becfd0c0cc925499222bbee", null ],
      [ "size", "group___n_v_m.html#gabb0d544f7f13eab892d315959435c453", null ],
      [ "start_addr", "group___n_v_m.html#ga89f0759d4cddab7feae7136541cb42af", null ]
    ] ],
    [ "NVM_VER_DEVELOP", "group___n_v_m.html#ga8290db7edebdb2145431ccf8dfa1682e", null ],
    [ "NVM_VER_MAJOR", "group___n_v_m.html#ga4246e6485ed9bd8eb226ef2ad91ff38f", null ],
    [ "NVM_VER_MINOR", "group___n_v_m.html#gae6a084d8ff61ab3cec0e10fe037533fb", null ],
    [ "nvm_mem_driver_t", "group___n_v_m.html#ga1985b8baf6174aa9863e48c74adaba2d", null ],
    [ "nvm_region_t", "group___n_v_m.html#gaabbbe4f5dc7b4a331f8b93ad4ace468b", null ],
    [ "nvm_status_t", "group___n_v_m.html#gaad41627dc36cbbe1c177db1018037fc6", [
      [ "eNVM_OK", "group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6ab8413bff85167eccea82d678055c59ef", null ],
      [ "eNVM_ERROR", "group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6a1251fb1bbb000c3aa5696f497d424332", null ]
    ] ],
    [ "eNVM_ERROR", "group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6a1251fb1bbb000c3aa5696f497d424332", null ],
    [ "eNVM_OK", "group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6ab8413bff85167eccea82d678055c59ef", null ],
    [ "nvm_erase", "group___n_v_m.html#ga6ed85dcebf677276e94fd8802a8e5715", null ],
    [ "nvm_init", "group___n_v_m.html#gaf5bd1a99e0570323b1c7d0e218382597", null ],
    [ "nvm_is_init", "group___n_v_m.html#gae2d3d1bc018e64b400787cf0d00cc779", null ],
    [ "nvm_read", "group___n_v_m.html#gaf25384cd500a2fd96ae4447e5752ab7d", null ],
    [ "nvm_write", "group___n_v_m.html#gaf1c5baaeed545800df4b58c74874b171", null ],
    [ "gb_is_init", "group___n_v_m.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_nvm_regions", "group___n_v_m.html#ga3ee3def97c427741b2922521d21f83a2", null ],
    [ "name", "group___n_v_m.html#ga1cd49c10b06e2dcdc6240a6b96bce792", null ],
    [ "p_driver", "group___n_v_m.html#gad7ff41080becfd0c0cc925499222bbee", null ],
    [ "pf_nvm_erase", "group___n_v_m.html#ga8241f1c0b5f60bc6170ad4cdd917dde2", null ],
    [ "pf_nvm_init", "group___n_v_m.html#ga27448056011e41e3d4e806150ff4d040", null ],
    [ "pf_nvm_read", "group___n_v_m.html#ga5beab15bdb96b939c2b810882d533171", null ],
    [ "pf_nvm_write", "group___n_v_m.html#ga193e95d9530c5f05e44c024c847fcc39", null ],
    [ "size", "group___n_v_m.html#gabb0d544f7f13eab892d315959435c453", null ],
    [ "start_addr", "group___n_v_m.html#ga89f0759d4cddab7feae7136541cb42af", null ]
];