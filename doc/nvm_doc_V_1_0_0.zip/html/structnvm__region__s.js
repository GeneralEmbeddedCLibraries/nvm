var structnvm__region__s =
[
    [ "name", "group___n_v_m.html#ga1cd49c10b06e2dcdc6240a6b96bce792", null ],
    [ "p_driver", "group___n_v_m.html#gad7ff41080becfd0c0cc925499222bbee", null ],
    [ "size", "group___n_v_m.html#gabb0d544f7f13eab892d315959435c453", null ],
    [ "start_addr", "group___n_v_m.html#ga89f0759d4cddab7feae7136541cb42af", null ]
];