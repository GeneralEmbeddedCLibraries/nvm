var nvm_8c =
[
    [ "nvm_erase", "group___n_v_m.html#ga6ed85dcebf677276e94fd8802a8e5715", null ],
    [ "nvm_init", "group___n_v_m.html#gaf5bd1a99e0570323b1c7d0e218382597", null ],
    [ "nvm_is_init", "group___n_v_m.html#gae2d3d1bc018e64b400787cf0d00cc779", null ],
    [ "nvm_read", "group___n_v_m.html#gaf25384cd500a2fd96ae4447e5752ab7d", null ],
    [ "nvm_write", "group___n_v_m.html#gaf1c5baaeed545800df4b58c74874b171", null ],
    [ "gb_is_init", "group___n_v_m.html#ga7aa5c1c01a25e6125e4771126667c385", null ],
    [ "gp_nvm_regions", "group___n_v_m.html#ga3ee3def97c427741b2922521d21f83a2", null ]
];