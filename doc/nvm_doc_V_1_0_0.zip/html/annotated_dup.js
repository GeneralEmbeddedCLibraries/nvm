var annotated_dup =
[
    [ "nvm_mem_driver_s", "structnvm__mem__driver__s.html", "structnvm__mem__driver__s" ],
    [ "nvm_region_s", "structnvm__region__s.html", "structnvm__region__s" ]
];