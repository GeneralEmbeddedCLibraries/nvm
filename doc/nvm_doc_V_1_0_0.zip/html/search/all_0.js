var searchData=
[
  ['envm_5ferror_0',['eNVM_ERROR',['../group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6a1251fb1bbb000c3aa5696f497d424332',1,'nvm.h']]],
  ['envm_5fok_1',['eNVM_OK',['../group___n_v_m.html#ggaad41627dc36cbbe1c177db1018037fc6ab8413bff85167eccea82d678055c59ef',1,'nvm.h']]]
];
