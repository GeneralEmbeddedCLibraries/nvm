var searchData=
[
  ['p_5fdriver_21',['p_driver',['../group___n_v_m.html#gad7ff41080becfd0c0cc925499222bbee',1,'nvm_region_s']]],
  ['pf_5fnvm_5ferase_22',['pf_nvm_erase',['../group___n_v_m.html#ga8241f1c0b5f60bc6170ad4cdd917dde2',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5finit_23',['pf_nvm_init',['../group___n_v_m.html#ga27448056011e41e3d4e806150ff4d040',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5fread_24',['pf_nvm_read',['../group___n_v_m.html#ga5beab15bdb96b939c2b810882d533171',1,'nvm_mem_driver_s']]],
  ['pf_5fnvm_5fwrite_25',['pf_nvm_write',['../group___n_v_m.html#ga193e95d9530c5f05e44c024c847fcc39',1,'nvm_mem_driver_s']]]
];
