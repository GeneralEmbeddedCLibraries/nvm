var searchData=
[
  ['nvm_5fstatus_5ft_49',['nvm_status_t',['../group___n_v_m.html#gaad41627dc36cbbe1c177db1018037fc6',1,'nvm.h']]]
];
