var searchData=
[
  ['name_39',['name',['../group___n_v_m.html#ga1cd49c10b06e2dcdc6240a6b96bce792',1,'nvm_region_s']]]
];
