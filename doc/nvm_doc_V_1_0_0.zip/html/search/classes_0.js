var searchData=
[
  ['nvm_5fmem_5fdriver_5fs_28',['nvm_mem_driver_s',['../structnvm__mem__driver__s.html',1,'']]],
  ['nvm_5fregion_5fs_29',['nvm_region_s',['../structnvm__region__s.html',1,'']]]
];
