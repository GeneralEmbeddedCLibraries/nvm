var searchData=
[
  ['gb_5fis_5finit_2',['gb_is_init',['../group___n_v_m.html#ga7aa5c1c01a25e6125e4771126667c385',1,'nvm.c']]],
  ['gp_5fnvm_5fregions_3',['gp_nvm_regions',['../group___n_v_m.html#ga3ee3def97c427741b2922521d21f83a2',1,'nvm.c']]]
];
