var searchData=
[
  ['nvm_5ferase_32',['nvm_erase',['../group___n_v_m.html#ga6ed85dcebf677276e94fd8802a8e5715',1,'nvm.c']]],
  ['nvm_5finit_33',['nvm_init',['../group___n_v_m.html#gaf5bd1a99e0570323b1c7d0e218382597',1,'nvm.c']]],
  ['nvm_5fis_5finit_34',['nvm_is_init',['../group___n_v_m.html#gae2d3d1bc018e64b400787cf0d00cc779',1,'nvm.c']]],
  ['nvm_5fread_35',['nvm_read',['../group___n_v_m.html#gaf25384cd500a2fd96ae4447e5752ab7d',1,'nvm.c']]],
  ['nvm_5fwrite_36',['nvm_write',['../group___n_v_m.html#gaf1c5baaeed545800df4b58c74874b171',1,'nvm.c']]]
];
